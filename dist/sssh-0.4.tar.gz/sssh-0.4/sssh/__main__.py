from .ssher import main

main()